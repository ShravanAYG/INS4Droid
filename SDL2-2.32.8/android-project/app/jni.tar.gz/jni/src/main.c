#include <SDL.h>

int WW, WH;

void getTouchPos(SDL_Event *e, int *x, int *y)
{
	if (e->type == SDL_FINGERDOWN || e->type == SDL_FINGERUP || e->type == SDL_FINGERMOTION) {
		*x = (int)(e->tfinger.x * WW);
		*y = (int)(e->tfinger.y * WH);
	} else if (e->type == SDL_MOUSEBUTTONDOWN || e->type == SDL_MOUSEBUTTONUP || e->type == SDL_MOUSEMOTION) {
		*x = e->motion.x;
		*y = e->motion.y;
	}
}

SDL_Rect drawExitMenu(SDL_Renderer *renderer)
{
	SDL_Rect modal;
	modal.w = WW * 0.25;
	modal.h = modal.w / 2;
	modal.x = (WW / 2) - modal.w / 2;
	modal.y = (WH / 2) - modal.h / 2;
	Uint8 r, g, b, a;
	SDL_GetRenderDrawColor(renderer, &r, &g, &b, &a);
	SDL_SetRenderDrawColor(renderer, 0, 0, 0, 220);
	SDL_RenderFillRect(renderer, &modal);
	SDL_SetRenderDrawColor(renderer, 255, 255, 255, 255);
	SDL_RenderDrawRect(renderer, &modal);
	SDL_SetRenderDrawColor(renderer, r, g, b, a);
	return modal;
}

int main(int argc, char *argv[])
{
	SDL_Init(SDL_INIT_VIDEO);

	SDL_Window *window = SDL_CreateWindow("INS4Droid",SDL_WINDOWPOS_UNDEFINED,SDL_WINDOWPOS_UNDEFINED,0, 0,SDL_WINDOW_FULLSCREEN_DESKTOP);
	if (!window) {
		SDL_Log("Failed to create window: %s", SDL_GetError());
		return 1;
	}
	SDL_GetWindowSize(window, &WW, &WH);
	SDL_Renderer *renderer = SDL_CreateRenderer(window, -1,
						    SDL_RENDERER_ACCELERATED | SDL_RENDERER_PRESENTVSYNC);
	SDL_SetRenderDrawColor(renderer, 255, 0, 255, 255);
	int running = 1;
	int exitMenu = 0;
	SDL_Event e;
	SDL_Rect modal = { 0 };
	while (running) {
		while (SDL_PollEvent(&e)) {
			if (e.type == SDL_QUIT) {
				running = 0;
			} else if (e.type == SDL_KEYDOWN && e.key.keysym.sym == SDLK_AC_BACK) {
				exitMenu = !exitMenu;
			} else if (exitMenu && (e.type == SDL_FINGERDOWN || e.type == SDL_MOUSEBUTTONDOWN)) {
				int x, y;
				getTouchPos(&e, &x, &y);
				if (x > modal.x && x < modal.x + modal.w && y > modal.y && y < modal.y + modal.h) {
					running = 0;
				} else
					exitMenu = 0;
			}
		}
		SDL_RenderClear(renderer);
		if (exitMenu)
			modal = drawExitMenu(renderer);
		SDL_RenderPresent(renderer);
		SDL_Delay(2);
	}
	SDL_Quit();
	return 0;
}
